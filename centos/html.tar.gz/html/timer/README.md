# 程序员的浪漫

## 示例网页
[http://thinkhard.tech/romantic_page/](http://thinkhard.tech/romantic_page/)

## 使用方法

原来 Gitpages 还可以这么使用，如果正在使用 Gitpages 搭建博客的话，可以将同个账号下另一个仓库 Html 网页进行显示,访问地址示例为

`http://userName.github.io/romantic_page`

![demo](https://ws1.sinaimg.cn/large/c3a916a7gy1fnqsygoap5j20le09e3z7.jpg)

## 效果图

![](./result.gif)

点 **Star** 或者 **Fork 的人**，祝你们幸福哦 ~
